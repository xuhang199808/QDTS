import itertools

import numpy as np
# import gym
# from gym import spaces
from qutip import basis, Qobj, fidelity, sigmax, sigmay, sigmaz, identity
from qutip import *
# from gym import spaces
import random
from hamiltonian import *
import copy


class QubitEnv():
    def __init__(self,
                 discrete_evolution, use_density_matrix, n_actions,
                 step_rate, total_T, dx, seed, Hamiltonian_params,
                 reward_form, max_qfi, N=10, psi_cavity=0, dqn_agent=True):
        super(QubitEnv, self).__init__()
        self.phy_model = QuantumRabiModel(**Hamiltonian_params)
        self.dqn_agent= dqn_agent
        self.N = N
        self.psi_cavity = psi_cavity
        bit = basis(2, 0) * basis(2, 0).dag()
        self.bit = bit
        self.initial_full_state = [tensor(bit, fock_dm(N, psi_cavity)),
                                   tensor(bit, fock_dm(N, psi_cavity))]  # Start with |0> state
        self.initial_bit_state = [bit, bit]
        self.steps = 0
        self.previous_reward = 0
        self.max_qfi = max_qfi #(16*t^2)
        self.total_T = total_T
        self.step_duration = 0.5*np.pi / step_rate  # Ensure that the evolution time of a round is fixed, and the time step is related to the maximum number of actions
        self.max_steps = total_T * step_rate
        self.reward_form = reward_form
        self.discrete_evolution = discrete_evolution
        self.use_density_matrix = use_density_matrix
        self.n_actions = n_actions
        self.dx = dx  # 被测参数的差分步长
        self.full_state = copy.deepcopy(self.initial_full_state)
        self.bit_state = copy.deepcopy(self.initial_bit_state)
        self.observation_space = np.append(self._get_obs(self.bit_state), self._get_obs(self.bit_state))
        self.observation_space = self._get_obs(self.bit_state)

        random.seed(seed)
        np.random.seed(seed)
        np.random.RandomState(seed)

        h_max = 1.0
        gx, gy, gz, gxy, gxz, gyz = {'gx': h_max}, {'gy': h_max}, {'gz': h_max}, {'gxy': h_max}, {'gxz': h_max}, {
            'gyz': h_max}
        ngx, ngy, ngz, ngxy, ngxz, ngyz = {'gx': -h_max}, {'gy': -h_max}, {'gz': -h_max}, {'gxy': -h_max}, {
            'gxz': -h_max}, {
            'gyz': -h_max}
        if self.discrete_evolution:
            if n_actions == 4:
                self.action_dicts = [gx, gz, ngx, ngz]
            else:
                assert False, "Number of actions not supported."
        else:
            if n_actions == 15:
                self.action_dicts = np.linspace(0.835, 1.165, 15)
            elif n_actions == 30:
                self.action_dicts = np.linspace(0.76, 1.24, 30)
            elif n_actions == 81:
                self.action_x = [-0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4]
                self.action_z = [-0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4]
                self.action_dicts = list(itertools.product(self.action_x, self.action_z))
            else:
                assert False, "Number of actions not supported."

    def reset(self, batch_size=10):
        # 创建一个初始量子态（这可以视为模板）
        full_state_template = [
            tensor(self.bit, coherent_dm(self.N, 1)),
            tensor(self.bit, coherent_dm(self.N, 1))
        ]  # Start with |0> state
        bit_state_template = [self.bit, self.bit]
        # 使用 deepcopy 确保每个量子态的副本是独立的
        full_state = copy.deepcopy(full_state_template)  # 返回batch_size个独立的量子态
        bit_state = copy.deepcopy(bit_state_template) # 返回batch_size个独立的比特状态

        return full_state, bit_state

    def _get_obs(self, bit_state):
        """用qubit及其微扰qubit的bloch参数作为特征"""
        obs_list = self.matrix_to_bloch(bit_state[0]) + self.matrix_to_bloch(bit_state[1])
        # obs_list = self.matrix_to_bloch(bit_state[0])
        return np.array(obs_list)

    def sme_evo(self, full_state, rng):

        duration = self.step_duration
        mid_bit_state = [None, None]
        mid_bit_state[0], mid_bit_state[1] = self.phy_model.sme_evolve(full_state, duration, self.dx, rng)
        obs = self._get_obs(mid_bit_state)
        return mid_bit_state

    def pred_sme_evo(self, full_state, rng):

        duration = self.step_duration
        mid_bit_state = [None, None]
        pred_mid_bit_state = [None, None]
        mid_bit_state[0], mid_bit_state[1], pred_mid_bit_state[0], pred_mid_bit_state[1] \
            = self.phy_model.pred_sme_evolve(full_state, duration, self.dx, rng)
        return mid_bit_state, pred_mid_bit_state

    def step(self, action, full_state, mid_bit, steps=1):
        action = self.phy_model.continue_action(self.action_dicts[int(action)])
        bit_state = [reduced_density_matrix(full_state[0]), reduced_density_matrix(full_state[1])]
        next_full_state, pred_next_bit_state = [None, None], [None, None]
        next_bit_state, pred_next_full_state = [None, None], [None, None]
        next_bit_state[0], next_bit_state[1], next_full_state[0], next_full_state[1] \
            = self.phy_model.control_evolve(mid_bit, action)
        or_reward = self.reward(bit_state, next_bit_state)

        if or_reward < np.log(350):
            reward = or_reward
        else:
            reward = or_reward

        done = steps >= self.max_steps - 1
        obs = self._get_obs(next_bit_state)
        full_state = next_full_state
        bit_state = next_bit_state
        pre_bit_state = pred_next_bit_state
        return full_state, bit_state, obs, reward, or_reward, done

    def reward(self, bit_state, next_bit_state):

        if self.reward_form == 'QFI':
            F = fidelity(next_bit_state[0], next_bit_state[1])
            QFI = 8 * (1 - F) / self.dx ** 2
            if QFI <= 0:
                QFI = 0.01
            r = np.log(QFI/self.max_qfi)
            return r
        elif self.reward_form == 'CFI':
            theta = 0*np.pi #0为z，0.5为x
            op = np.sin(theta)*sigmax()+np.cos(theta)*sigmaz()
            X0 = expect(op, next_bit_state[0])
            X1 = expect(op, next_bit_state[1])
            X2 = (X0+X1)/2
            CFI = (((X1 - X0) ** 2) / self.dx ** 2)/(1 - X2**2)
            if CFI <= 0:
                CFI = 0.01
            r = CFI/self.max_qfi
            return np.log(r.real)

    def matrix_to_bloch(self, rho):
        """
        把qubit密度矩阵转化bloch向量。
        """
        sx = sigmax()
        sy = sigmay()
        sz = sigmaz()
        # 计算期望值
        ex = expect(sx, rho)
        ey = expect(sy, rho)
        ez = expect(sz, rho)
        # Bloch 矢量
        bloch_vector = [ex, ey, ez]
        return bloch_vector

    def bloch_to_matrix(self, bloch_vector):
        """
        把bloch向量转换为密度矩阵。
        """
        rho_11 = basis(2, 0) * basis(2, 0).dag()
        rho_22 = basis(2, 1) * basis(2, 1).dag()
        rho_12 = basis(2, 0) * basis(2, 1).dag()
        rho_21 = basis(2, 1) * basis(2, 0).dag()
        rho = 1 / 2 * ((1 + bloch_vector[2]) * rho_11 + (1 - bloch_vector[2]) * rho_22 +
                       (bloch_vector[0] - 1j * bloch_vector[1]) * rho_12 + (
                               bloch_vector[0] + 1j * bloch_vector[1]) * rho_21)
        return rho

    def random_state(self, x):
        """
        生成一个由角度 theta 和 phi 参数化的单粒子布洛赫球状态，
        如果 use_density_matrix 为 True，则返回对应的密度矩阵。
        """
        theta = np.random.uniform(0, np.pi)  # θ in [0, π]
        phi = np.random.uniform(0, 2 * np.pi)  # φ in [0, 2π]
        length = np.random.uniform(x, 1)  # 布洛赫矢量的长度
        if self.use_density_matrix:
            bloch_r = length * [np.sin(theta) * np.cos(phi), np.sin(theta) * np.sin(phi), np.cos(theta)]
            rho_11 = basis(2, 0) * basis(2, 0).dag()
            rho_22 = basis(2, 1) * basis(2, 1).dag()
            rho_12 = basis(2, 0) * basis(2, 1).dag()
            rho_21 = basis(2, 1) * basis(2, 0).dag()
            rho = 1 / 2 * ((1 + bloch_r[2]) * rho_11 + (1 - bloch_r[2]) * rho_22 +
                           (bloch_r[0] - 1j * bloch_r[1]) * rho_12 + (bloch_r[0] + 1j * bloch_r[1]) * rho_21)
            return rho
        else:
            return np.cos(theta / 2) * basis(2, 0) + np.exp(1.j * phi) * np.sin(theta / 2) * basis(2, 1)

    def render(self, mode='human'):
        pass
