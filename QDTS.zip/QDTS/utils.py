from qutip import *
import numpy as np
import sys
import os


def matrix_to_bloch(rho):
    """
    把qubit密度矩阵转化bloch向量。
    """
    sx = sigmax()
    sy = sigmay()
    sz = sigmaz()
    # 计算期望值
    ex = expect(sx, rho)
    ey = expect(sy, rho)
    ez = expect(sz, rho)
    # Bloch 矢量
    bloch_vector = [ex, ey, ez]
    return bloch_vector

def bloch_to_matrix(bloch_vector):
    """
    把bloch向量转换为密度矩阵。
    """
    rho_11 = basis(2, 0) * basis(2, 0).dag()
    rho_22 = basis(2, 1) * basis(2, 1).dag()
    rho_12 = basis(2, 0) * basis(2, 1).dag()
    rho_21 = basis(2, 1) * basis(2, 0).dag()
    rho = 1 / 2 * ((1 + bloch_vector[2]) * rho_11 + (1 - bloch_vector[2]) * rho_22 +
                   (bloch_vector[0] - 1j * bloch_vector[1]) * rho_12 + (
                           bloch_vector[0] + 1j * bloch_vector[1]) * rho_21)
    return rho

def get_obs(bit_state):
    """用qubit及其微扰qubit的bloch参数作为特征"""
    # obs_list = matrix_to_bloch(bit_state[0])
    obs_list = matrix_to_bloch(bit_state[0]) + matrix_to_bloch(bit_state[1])
    return np.array(obs_list)

def reduced_density_matrix(psi):
    return psi.ptrace(0)  # 对量子比特进行约化

def random_state(use_density_matrix, x):
    """
    生成一个由角度 theta 和 phi 参数化的单粒子布洛赫球状态，
    如果 use_density_matrix 为 True，则返回对应的密度矩阵。
    """
    theta = np.random.uniform(0, np.pi)  # θ in [0, π]
    phi = np.random.uniform(0, 2 * np.pi)  # φ in [0, 2π]
    length = np.random.uniform(x, 1)  # 布洛赫矢量的长度
    if use_density_matrix:
        bloch_r = length * [np.sin(theta) * np.cos(phi), np.sin(theta) * np.sin(phi), np.cos(theta)]
        rho_11 = basis(2, 0) * basis(2, 0).dag()
        rho_22 = basis(2, 1) * basis(2, 1).dag()
        rho_12 = basis(2, 0) * basis(2, 1).dag()
        rho_21 = basis(2, 1) * basis(2, 0).dag()
        rho = 1 / 2 * ((1 + bloch_r[2]) * rho_11 + (1 - bloch_r[2]) * rho_22 +
                       (bloch_r[0] - 1j * bloch_r[1]) * rho_12 + (bloch_r[0] + 1j * bloch_r[1]) * rho_21)
        return rho
    else:
        return np.cos(theta / 2) * basis(2, 0) + np.exp(1.j * phi) * np.sin(theta / 2) * basis(2, 1)
