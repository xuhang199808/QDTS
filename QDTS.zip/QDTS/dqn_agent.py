import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque
from phy_env import *


def matrix_to_bloch(rho):

    sx = sigmax()
    sy = sigmay()
    sz = sigmaz()
    ex = expect(sx, rho)
    ey = expect(sy, rho)
    ez = expect(sz, rho)
    bloch_vector = [ex, ey, ez]
    return bloch_vector


def get_obs(bit_state):

    obs_list = matrix_to_bloch(bit_state[0]) + matrix_to_bloch(bit_state[1])
    # obs_list = matrix_to_bloch(bit_state[0])
    return np.array(obs_list)


class DQN(nn.Module):
    def __init__(self, observation_space, action_space):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(observation_space.shape[0], 48)
        self.fc2 = nn.Linear(48, 100)
        self.fc3 = nn.Linear(100, 100)
        self.fc4 = nn.Linear(100, action_space)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        return self.fc4(x)


class Agent:
    def __init__(self, observation_space, action_space, env, learning_rate=0.001, batch_size=128):
        self.env = env
        self.observation_space = observation_space
        self.action_space = action_space
        self.memory = deque(maxlen=1000)
        self.gamma = 0.98
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.model = DQN(observation_space, action_space)
        self.target_model = DQN(observation_space, action_space)
        self.update_target_model()
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate)
        self.scheduler = optim.lr_scheduler.StepLR(self.optimizer, step_size=100, gamma=0.9)  # Learning rate decay
        self.loss_fn = nn.MSELoss()

    def update_target_model(self):
        self.target_model.load_state_dict(self.model.state_dict())

    def act(self, bit_obs, eps):
        if np.random.rand() <= eps:
            return random.randrange(self.env.n_actions)
        obs = bit_obs
        state = torch.FloatTensor(obs).unsqueeze(0)
        act_values = self.model(state)[0]
        return torch.argmax(act_values).item()

    def continuous_act(self, bit_state, mid_bit, eps):
        if np.random.rand() <= eps:
            return random.choice([-0.4, -0.3, -0.2, -0.1, 0, 0.1, 0.2, 0.3, 0.4])
        obs = np.append(get_obs(bit_state), get_obs(mid_bit))
        state = torch.FloatTensor(obs).unsqueeze(0)
        act_values = self.model(state)[0]
        return torch.argmax(act_values).item()

    def remember(self, bit_state, action, reward, next_bit_state, done):
        self.memory.append((bit_state, action, reward, next_bit_state, done))

    def replay(self):  # dqn
        if len(self.memory) < self.batch_size:
            return
        minibatch = random.sample(self.memory, self.batch_size)
        for bit_obs, action, reward, next_bit_obs, done in minibatch:
            target = reward
            if not done:
                next_bit_state = torch.FloatTensor(next_bit_obs).unsqueeze(0)
                # next_state = torch.FloatTensor(next_state).unsqueeze(0)
                target = reward + self.gamma * torch.max(self.target_model(next_bit_state)).item()
            bit_state = torch.FloatTensor(bit_obs).unsqueeze(0)
            target_f = self.model(bit_state)
            target_f[0][action] = target
            self.optimizer.zero_grad()
            loss = self.loss_fn(target_f, self.model(bit_state))
            loss.backward()
            self.optimizer.step()


    def save_model(self, filepath):
        """Save the current model to a file."""
        torch.save(self.model.state_dict(), filepath)

    def load_model(self, filepath):
        """Load model weights from a file."""
        self.model.load_state_dict(torch.load(filepath))
        self.model.eval()  # Set the model to evaluation mode


