from qutip import *
import numpy as np
import sys
import os
from contextlib import contextmanager
from rnn.model import QuantumRabiRNN
import torch
import torch.nn as nn

@contextmanager
def suppress_output():
    sys.stdout = open(os.devnull, 'w')
    try:
        yield
    finally:
        sys.stdout = sys.__stdout__

def reduced_density_matrix(psi):
    return psi.ptrace(0)


class QuantumRabiModel:
    def __init__(self, w0, w_c, g, N, meas_strength):

        self.w0 = w0
        self.w_c = w_c
        self.g = g
        self.N = N

        self.sigmax = sigmax()
        self.sigmay = sigmay()
        self.sigmaz = sigmaz()
        # The annihilation operator of the cavity
        self.a = destroy(N)
        self.meas_strength = meas_strength


    def continue_action(self, t):

        op = t * self.sigmaz

        return op

    def _define_hamiltonian(self, dx):
        """
        定义量子Rabi模型的哈密顿量。
        """
        H0 = np.sin(2*(self.w0 + dx)) * tensor(self.sigmaz, qeye(self.N)) \
            + np.cos(2*(self.w0 + dx)) * tensor(self.sigmax, qeye(self.N))
        H_int = tensor(np.sin(2*(self.w0 + dx)) * self.sigmaz + np.cos(2*(self.w0 + dx))*self.sigmax, (self.a.dag()*self.a))
        # H_int = tensor(self.sigmaz, (self.a.dag()*self.a))
        H = H0 + self.g * H_int

        return H

    def sme_evolve(self, psi, duration, dx, rng):

        # psi = psi.ptrace(0)
        tlist = np.linspace(0, duration, 400)
        meas_strength = self.meas_strength
        e_ops = [tensor(qeye(2), self.a + self.a.dag()), tensor(self.sigmax, qeye(self.N)),
                 tensor(self.sigmay, qeye(self.N)),
                 tensor(self.sigmaz, qeye(self.N))]

        hamiltonian1 = self._define_hamiltonian(0)
        hamiltonian2 = self._define_hamiltonian(dx)
        options = Options(store_states=True)
        with suppress_output():
            rng_state = rng.bit_generator.state
            np.random.seed(rng.integers(0, 2 ** 32 - 1))
            result1 = smesolve(hamiltonian1, psi[0], tlist, sc_ops=[meas_strength * tensor(qeye(2), self.a.dag()*self.a)],
                              e_ops=e_ops, options=options)
            rng.bit_generator.state = rng_state
            np.random.seed(rng.integers(0, 2 ** 32 - 1))
            result2 = smesolve(hamiltonian2, psi[1], tlist, sc_ops=[meas_strength * tensor(qeye(2), self.a.dag()*self.a)],
                              e_ops=e_ops, options=options)
        expectation1 = result1.expect
        expectation2 = result2.expect
        state1 = result1.states[0][-1]
        state2 = result2.states[0][-1]
        bit1, bit2 = state1.ptrace(0), state2.ptrace(0)
        # print(f"purity:{(bit1 ** 2).tr()}")
        x1_f = expectation1[1][-1]
        y1_f = expectation1[2][-1]
        z1_f = expectation1[3][-1]
        x2_f = expectation2[1][-1]
        y2_f = expectation2[2][-1]
        z2_f = expectation2[3][-1]
        qubit1 = 0.5 * (qeye(2) + x1_f * self.sigmax + y1_f * self.sigmay + z1_f * self.sigmaz)
        qubit2 = 0.5 * (qeye(2) + x2_f * self.sigmax + y2_f * self.sigmay + z2_f * self.sigmaz)


        return qubit1, qubit2

    def pred_sme_evolve(self, psi, duration, dx, rng):
        """
        对系统进行时间演化。

        参数:
        psi: 初始态
        tlist: 时间点列表

        返回:
        result: 演化结果
        """
        # psi = psi.ptrace(0)
        tlist = np.linspace(0, duration, 400)
        meas_strength = 1.5
        e_ops = [tensor(qeye(2), self.a + self.a.dag()), tensor(self.sigmax, qeye(self.N)),
                 tensor(self.sigmay, qeye(self.N)),
                 tensor(self.sigmaz, qeye(self.N))]

        hamiltonian1 = self._define_hamiltonian(0)
        hamiltonian2 = self._define_hamiltonian(dx)
        with suppress_output():
            rng_state = rng.bit_generator.state
            np.random.seed(rng.integers(0, 2 ** 32 - 1))
            result1 = smesolve(hamiltonian1, psi[0], tlist, sc_ops=[meas_strength * tensor(qeye(2), self.a.dag()*self.a)],
                              e_ops=e_ops)
            rng.bit_generator.state = rng_state
            np.random.seed(rng.integers(0, 2 ** 32 - 1))
            result2 = smesolve(hamiltonian2, psi[1], tlist, sc_ops=[meas_strength * tensor(qeye(2), self.a.dag()*self.a)],
                              e_ops=e_ops)
        expectation1 = result1.expect
        expectation2 = result2.expect
        x1_f = expectation1[1][-1]
        y1_f = expectation1[2][-1]
        z1_f = expectation1[3][-1]
        x2_f = expectation2[1][-1]
        y2_f = expectation2[2][-1]
        z2_f = expectation2[3][-1]
        qubit1 = 0.5 * (qeye(2) + x1_f * self.sigmax + y1_f * self.sigmay + z1_f * self.sigmaz)
        qubit2 = 0.5 * (qeye(2) + x2_f * self.sigmax + y2_f * self.sigmay + z2_f * self.sigmaz)

        record1, record2 = expectation1[0].flatten()[::2], expectation1[1].flatten()[::2]
        bit = [reduced_density_matrix(psi[0]), reduced_density_matrix(psi[1])]
        # pre_bit = [reduced_density_matrix(psi[0]), reduced_density_matrix(psi[1])]
        bit1_obs = self.single_obs(bit[0])
        bit2_obs = self.single_obs(bit[1])
        pred_qubit1 = self.predict_quantum_state(bit1_obs, record1, dx=0)
        pred_qubit2 = self.predict_quantum_state(bit2_obs, record1, dx=dx)
        return qubit1, qubit2, pred_qubit1, pred_qubit2

    def control_evolve(self, mid_qubit, action):

        U = (-1j * action * np.pi/2).expm()
        next_qubit1, next_qubit2 = U * mid_qubit[0] * U.dag(), U * mid_qubit[1] * U.dag()
        psi1 = tensor(next_qubit1, coherent_dm(self.N, 1))
        psi2 = tensor(next_qubit2, coherent_dm(self.N, 1))
        return next_qubit1, next_qubit2, psi1, psi2

    def predict_quantum_state(self, initial_state, measurement_sequence, dx, input_size=1, rnn_units=128, hidden_units=64):
        """
        Predict quantum states with saved models

        Parameter:
            model_path (str): 模型路径（如 ./save/quantum_rabi_rnn_epoch_10.pth）
            initial_state (ndarray): 初始量子态 (x, y, z) 的 NumPy 数组，形状为 (3,)
            measurement_sequence (ndarray): 测量序列数据，形状为 (seq_length,)
            input_size (int): RNN 输入维度
            rnn_units (int): RNN 隐藏单元数量
            hidden_units (int): 全连接层隐藏单元数量

        Return:
            predicted_state (ndarray): (x, y, z)
        """
        # 加载模型
        model = QuantumRabiRNN(input_size, rnn_units, hidden_units)
        if dx == 0:
            model_path = "./rnn/save/quantum_rabi_rnn.pth"
        else:
            model_path = "./rnn/save/quantum_rabi_rnndx.pth"
        model.load_state_dict(torch.load(model_path, weights_only=True))
        model.eval()

        # 将输入数据转换为 PyTorch 张量
        initial_state_tensor = torch.tensor(initial_state, dtype=torch.float32).unsqueeze(0)  # 添加 batch 维度
        measurement_sequence_tensor = torch.tensor(measurement_sequence, dtype=torch.float32).unsqueeze(0).unsqueeze(-1)

        # 模型预测
        with torch.no_grad():
            pred_obs = model(initial_state_tensor, measurement_sequence_tensor).squeeze(0).numpy()
        pred_bit = 0.5 * (qeye(2) + pred_obs[0] * self.sigmax
                                 + pred_obs[1] * self.sigmay + pred_obs[2] * self.sigmaz)

        # 将结果转换为 NumPy 数组
        return pred_bit

    def matrix_to_bloch(self, rho):
        """
        把qubit密度矩阵转化bloch向量。
        """
        sx = sigmax()
        sy = sigmay()
        sz = sigmaz()
        # 计算期望值
        ex = expect(sx, rho)
        ey = expect(sy, rho)
        ez = expect(sz, rho)
        # Bloch 矢量
        bloch_vector = [ex, ey, ez]
        return bloch_vector


    def single_obs(self, bit_state):
        """用qubit及其微扰qubit的bloch参数作为特征"""
        # obs_list = self.matrix_to_bloch(bit_state[0]) + self.matrix_to_bloch(bit_state[1])
        obs_list = self.matrix_to_bloch(bit_state)
        return np.array(obs_list)