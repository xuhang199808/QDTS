# import gym
import numpy as np
from phy_env import QubitEnv
from dqn_agent import Agent
from qutip import basis
from itertools import count
import matplotlib.pyplot as plt
import math
import time
from qutip import *
from utils import *
import sys
from numpy.random import default_rng

rng = default_rng(seed=42)
pred_model = True
N = 4
w0 = 0.75
g = 0.1
meas_strength = 1.5
n_actions = 15
max_T = 10
max_qfi1 = 1600
max_qfi = max_qfi1/4
print(f"g={g}, n_cavity={N},n_actions={n_actions}")
def use_pred_sme(env, full_state, rng):

    if pred_model:
        mid_bit, pred_mid_bit = env.pred_sme_evo(full_state, rng=rng)
        mid_bit_obs = get_obs(pred_mid_bit)
    else:
        mid_bit = env.sme_evo(full_state, rng=rng)
        mid_bit_obs = get_obs(mid_bit)
    return mid_bit, mid_bit_obs

def memory_init(env, agent, buffer_size, eps=1.0):
    """ Fills replay buffer by taking random actions"""
    full_state, bit_state = env.reset()
    mid_bit, mid_bit_obs = use_pred_sme(env, full_state, rng=rng)

    step_count = 0
    for i in range(buffer_size):
        step_count += 1
        # bit_obs = np.append(get_obs(bit_state), get_obs(mid_bit))
        bit_obs = mid_bit_obs
        action = agent.act(bit_obs, eps=eps)
        next_full_state, next_bit_state, obs, reward, or_reward, done\
            = env.step(action, full_state, mid_bit, steps=step_count)

        next_mid_bit, next_mid_bit_obs = use_pred_sme(env, next_full_state, rng=rng)
        next_bit_obs = next_mid_bit_obs
        reward = (np.exp(or_reward) * max_qfi - 4 * (step_count) ** 2)/(4 * (step_count) ** 2) #CFI=4*reward
        agent.remember(bit_obs, action, reward, next_bit_obs, done)
        full_state, bit_state = next_full_state, next_bit_state
        mid_bit = next_mid_bit
        mid_bit_obs = next_mid_bit_obs
        if step_count >= max_T:
            full_state, bit_state = env.reset()
            # mid_bit = env.sme_evo(full_state, rng=rng)
            mid_bit, mid_bit_obs = use_pred_sme(env, full_state, rng=rng)
            step_count = 0




Hamiltonian_params = dict(
    w0=w0,  # Frequency of the bit
    w_c=0,  # Frequency of the cavity
    g=g,  # bit and cavity coupling coefficient
    N=N,  # Maximum number of photons
    meas_strength=meas_strength
)

Env_params = dict(
    discrete_evolution=False,
    use_density_matrix=True,
    n_actions=n_actions,  # action set size
    step_rate=1,  # [2, 3, 4, 5, 6]
    total_T=max_T,  # total_evolve = total_T * np.pi
    dx=0.001,
    seed=2024,
    Hamiltonian_params=Hamiltonian_params,
    reward_form='CFI',#CEI:dx=0.001,QFI:dx=0.01
    max_qfi=max_qfi1,
    N=N,  # Maximum number of photons
    # psi_cavity=basis(10, 1),
    psi_cavity=0,  # fock_state
    dqn_agent=True
)


def main():

    batch_size = 64
    lr = 0.001
    buffer_size = 50
    episodes = 600
    eps_init = 1.0
    eps_final = 0.05

    env = QubitEnv(**Env_params)
    agent = Agent(env.observation_space, n_actions, env,
                  learning_rate=lr, batch_size=batch_size)

    rewards, epsilon = [], []

    start_time = time.time()
    memory_init(env, agent, buffer_size, eps=eps_init)
    print("\n\nDone filling replay buffer: --- {:.4f} seconds ---"
          .format(time.time() - start_time))

    start_time = time.time()
    for e in range(episodes):
        print(f"Episode: {e}/{episodes}")
        full_state, bit_state = env.reset()
        # mid_bit = env.sme_evo(full_state, rng=rng)
        mid_bit, mid_bit_obs = use_pred_sme(env, full_state, rng=rng)

        eps = eps_final + (eps_init - eps_final) * math.exp(-8. * e / episodes)
        action_list, reward_step = [], []
        for step in count():

            # bit_obs = np.append(get_obs(bit_state), get_obs(mid_bit))
            bit_obs = mid_bit_obs
            action = agent.act(bit_obs, eps=eps)

            action_list.append(action)
            next_full_state, next_bit_state, obs, reward, or_reward, done\
                = env.step(action, full_state, mid_bit, steps=step)

            next_mid_bit, next_mid_bit_obs = use_pred_sme(env, next_full_state, rng=rng)
            next_bit_obs = next_mid_bit_obs
            reward = (np.exp(or_reward)*max_qfi - 4*(step+1)**2)/(4*(step+1)**2)
            agent.remember(bit_obs, action, reward, next_bit_obs, done)
            full_state, bit_state = next_full_state, next_bit_state
            mid_bit = next_mid_bit
            mid_bit_obs = next_mid_bit_obs
            reward_step.append(np.exp(or_reward)*max_qfi)
            if done:

                final_reward = np.exp(or_reward)*max_qfi
                rewards.append(final_reward)
                epsilon.append(eps)
                agent.update_target_model()
                print(f"Episode: {e + 1}/{episodes}, Action_number: {step + 1}, "
                      f"Epsilon: {eps}, Final_reward: {final_reward}, ")
                print("Elapsed time: {:.4f}".format(time.time() - start_time))
                if e > episodes-100:
                    if final_reward >= 350:
                        print("Actions taken: ", action_list)
                        print("Reward process: ", reward_step)
                        if pred_model:
                            model_path = f"./save_model/Pred_model/w0{w0}T{max_T}g{g}action{n_actions}episode_{e + 1}_reward_{int(final_reward)}.pth"
                        else:
                            model_path = f"./save_model/Real_model/w0{w0}T{max_T}g{g}action{n_actions}episode_{e + 1}_reward_{int(final_reward)}.pth"
                        agent.save_model(model_path)
                start_time = time.time()
                break
            agent.replay()

    plt.plot(rewards)
    plt.xlabel('episodes')
    plt.ylabel('rewards')
    plt.savefig('./save_data/Reward_vs_episodes.png')
    plt.show()
    np.save('./save_data/Reward_episode.npy', rewards)


if __name__ == "__main__":
    main()
