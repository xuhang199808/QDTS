from qutip import sigmax, sigmay, sigmaz, expect
import numpy as np

# 计算泡利期望值
def get_pauli_expectations(state):
    sigma_x = sigmax()
    sigma_y = sigmay()
    sigma_z = sigmaz()
    return [expect(sigma_x, state), expect(sigma_y, state), expect(sigma_z, state)]

# 加载保存的数据
def load_data(filename):
    data = np.load(filename)
    return data['X'], data['Y']

if __name__ == "__main__":
    print("Utility functions loaded!")