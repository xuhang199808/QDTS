import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
import os
from qutip import *


# 数据集类
class QuantumRabiDataset(Dataset):
    def __init__(self, data_file):
        # Load data from file
        saved_data = torch.load(data_file)
        self.data = saved_data['data']
        self.labels = saved_data['labels']

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        initial_state, measurement_sequence = self.data[idx]
        final_state = self.labels[idx]
        return {
            'initial_state': torch.tensor(initial_state, dtype=torch.float32),
            'measurement_sequence': torch.tensor(measurement_sequence, dtype=torch.float32),
            'final_state': torch.tensor(final_state, dtype=torch.float32)
        }

N=4
a = destroy(N)
sigmax = sigmax()
sigmay = sigmay()
sigmaz = sigmaz()
meas_op = a.dag() * a

def define_hamiltonian(w_c, g, w0):

    dx = 0.00 #dx=0.01
    print(f"dx={dx}")
    H_q = np.sin(2*(w0+dx))*sigmaz+np.cos(2*(w0+dx))*sigmax
    H0 = tensor(H_q, qeye(N))
    H1 = w_c * tensor(qeye(2), a.dag() * a)
    H_int = g * tensor(H_q, meas_op)
    H = H0 + H1 + H_int
    return H

def random_state(theta, phi, length):

    x = length * np.cos(phi) * np.sin(theta)
    y = length * np.sin(phi) * np.sin(theta)
    z = length * np.cos(theta)
    return np.array([x, y, z])

def evolve(psi_bit, duration, w0, g, meas_strength, alpha):

    tlist = np.linspace(0, duration, 400)
    psi = tensor(psi_bit, coherent_dm(N, 1))
    hamiltonian = define_hamiltonian(w0, g, alpha)
    e_ops = [tensor(qeye(2), meas_op), tensor(sigmax, qeye(N)), tensor(sigmay, qeye(N)), tensor(sigmaz, qeye(N))]
    result = smesolve(hamiltonian, psi, tlist, [], [meas_strength * tensor(qeye(2), meas_op)], e_ops=e_ops)
    # print(result.states[-1])
    return result


# 生成数据并保存到文件
def generate_and_save_data(num_samples, seq_length, file_path):
    data = []
    labels = []

    for _ in range(num_samples):

        theta = np.random.uniform(0, np.pi)  # θ in [0, π]
        phi = np.random.uniform(0, 2 * np.pi)  # φ in [0, 2π]
        length = np.random.uniform(0.9, 1)  # The length of the Bloch vector
        duration=np.pi/2
        w0=0.75
        w_c=0
        g=0.1
        meas_strength=1.5
        initial_state = random_state(theta, phi, length)

        psi_bit = 0.5 * (qeye(2) + initial_state[0]*sigmax + initial_state[1]*sigmay + initial_state[2]*sigmaz)

        # Extract the homodyne measurement
        expect = evolve(psi_bit, duration, w_c, g, meas_strength, w0).expect
        measurement_sequence = expect[0].flatten()
        measurement_record = measurement_sequence[::2]
        # Extract the terminal Pauli expectation (x_f, y_f, z_f) as a label
        x_f = expect[1][-1]
        y_f = expect[2][-1]
        z_f = expect[3][-1]
        final_state = np.array([x_f, y_f, z_f]).flatten()
        data.append((initial_state, measurement_record))
        labels.append(final_state)

    # Save data to file
    torch.save({'data': data, 'labels': labels}, file_path)
    print(f"Data saved to {file_path}")

# Create a data loader
def create_dataloader(data_file, batch_size):
    dataset = QuantumRabiDataset(data_file)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
    return dataloader