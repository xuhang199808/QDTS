import torch
import torch.nn as nn

class QuantumRabiRNN(nn.Module):
    def __init__(self, input_size, rnn_units, hidden_units):
        super(QuantumRabiRNN, self).__init__()
        self.rnn = nn.RNN(input_size, rnn_units, batch_first=True)
        self.fc1 = nn.Linear(3 + rnn_units, hidden_units)  # 3 for (x0, y0, z0) + rnn output
        self.fc2 = nn.Linear(hidden_units, hidden_units)
        self.output_layer = nn.Linear(hidden_units, 3)  # Output (xf, yf, zf)

    def forward(self, initial_state, measurement_sequence):
        rnn_out, _ = self.rnn(measurement_sequence)
        rnn_out_last = rnn_out[:, -1, :]  # Use the last RNN output
        combined = torch.cat((initial_state, rnn_out_last), dim=1)
        x = torch.relu(self.fc1(combined))
        x = torch.relu(self.fc2(x))
        output = self.output_layer(x)
        return output