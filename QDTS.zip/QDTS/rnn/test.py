import torch
import torch.nn as nn
from data_generation import create_dataloader
from data_generation import create_dataloader, generate_and_save_data
from model import QuantumRabiRNN
import os


def test(model, test_loader, criterion):
    model.eval()
    total_loss = 0
    correct = 0
    total = 0

    with torch.no_grad():
        for batch in test_loader:
            initial_state = batch['initial_state']
            measurement_sequence = batch['measurement_sequence'].unsqueeze(-1)
            final_state = batch['final_state']

            predictions = model(initial_state, measurement_sequence)
            loss = criterion(predictions, final_state)
            total_loss += loss.item()
            # print(f"predictions{predictions}")
            # print(f"final_state{final_state}")
            correct_predictions = (predictions.argmax(dim=1) == final_state.argmax(dim=1)).sum().item()
            total += final_state.size(0)
            correct += correct_predictions

        avg_loss = total_loss / len(test_loader)
        accuracy = correct / total
        # print(f"Test Loss: {avg_loss:.4f}, Accuracy: {accuracy:.4f}")
    return avg_loss, accuracy

# 测试的超参数设置
def get_testing_parameters():
    return {
        "input_size": 1,         # Measure the size of the input feature of the sequence
        "rnn_units": 128,        # Number of units in the RNN layer
        "hidden_units": 64,
        "batch_size": 32,
        "seq_length": 200,        # Measure sequence length
        "num_test_samples": 500,
        "test_data_path": "data/test_data.pt"
    }

# If the file does not exist, generate and save the test data
def check_and_generate_test_data(test_params):
    # Create a data folder if it doesn't exist
    os.makedirs(os.path.dirname(test_params["test_data_path"]), exist_ok=True)
    # generate_and_save_data(test_params["num_test_samples"], test_params["seq_length"], test_params["test_data_path"])
    if not os.path.exists(test_params["test_data_path"]):
        generate_and_save_data(test_params["num_test_samples"], test_params["seq_length"], test_params["test_data_path"])