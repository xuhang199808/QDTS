import torch
import torch.optim as optim
import torch.nn as nn
from data_generation import create_dataloader
from model import QuantumRabiRNN
from train import train, get_training_parameters, check_and_generate_data
from test import test, get_testing_parameters, check_and_generate_test_data
import numpy as np
import random




def set_seed(seed_value):

    random.seed(seed_value)
    np.random.seed(seed_value)
    torch.manual_seed(seed_value)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed_value)
        torch.cuda.manual_seed_all(seed_value)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


set_seed(2024)

if __name__ == "__main__":
    # Training parameters
    train_params = get_training_parameters()
    # Examine and generate training data
    check_and_generate_data(train_params)
    train_loader = create_dataloader(train_params["train_data_path"], train_params["batch_size"])

    # Test parameters
    test_params = get_testing_parameters()
    # Examine and generate test data
    check_and_generate_test_data(test_params)
    test_loader = create_dataloader(test_params["test_data_path"], test_params["batch_size"])

    # Instantiate the model
    model = QuantumRabiRNN(train_params["input_size"], train_params["rnn_units"], train_params["hidden_units"])

    # Loss function and optimizer
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=train_params["learning_rate"])

    # Train the model
    train(model, train_loader, test_loader, optimizer, criterion, train_params["num_epochs"])

    # Save the model
    torch.save(model.state_dict(), "./save/quantum_rabi_rnn.pth")
    # print("Model saved as quantum_rabi_rnn.pth")





    # Load the model
    model.load_state_dict(torch.load("./save/quantum_rabi_rnn.pth"))
    model.eval()

    # Test the model
    test(model, test_loader, criterion)