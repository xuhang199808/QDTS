import torch
import torch.optim as optim
import torch.nn as nn
from data_generation import create_dataloader
from model import QuantumRabiRNN
import os
from data_generation import create_dataloader, generate_and_save_data
import matplotlib.pyplot as plt
import numpy as np
from test import test


def train(model, train_loader, test_loader, optimizer, criterion, num_epochs):
    model.train()
    train_avg_loss_list = []
    test_avg_loss_list = []
    for epoch in range(num_epochs):
        total_loss = 0

        # Training loop for each batch
        for batch in train_loader:
            initial_state = batch['initial_state']
            measurement_sequence = batch['measurement_sequence'].unsqueeze(-1)
            final_state = batch['final_state']

            optimizer.zero_grad()
            predictions = model(initial_state, measurement_sequence)
            loss = criterion(predictions, final_state)
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        train_avg_loss = total_loss / len(train_loader)
        train_avg_loss_list.append(train_avg_loss)
        print(f"Epoch [{epoch + 1}/{num_epochs}], train loss: {train_avg_loss:.4f}")

        # Tests are performed after each epoch is completed
        print(f"Testing after epoch {epoch + 1}:")
        test_avg_loss, test_accuracy = test(model, test_loader, criterion)  # Call the test function
        print(f"Test Loss: {test_avg_loss:.4f}, Accuracy: {test_accuracy:.4f}")
        test_avg_loss_list.append(test_avg_loss)
    plt.plot(np.log10(train_avg_loss_list), label='Train')
    plt.plot(np.log10(test_avg_loss_list), label='Test')
    plt.xlabel('episodes')
    plt.ylabel(r'$lg_{\rm{loss}}$')
    plt.legend()
    plt.savefig('loss.pdf')
    plt.show()


# 训练的超参数设置
def get_training_parameters():
    return {
        "input_size": 1,              # Measure the size of the input feature of the sequence
        "rnn_units": 128,             # Number of units in the RNN layer
        "hidden_units": 64,
        "batch_size": 32,
        "num_epochs": 300,
        "learning_rate": 0.0005,
        "seq_length": 200,            # Measure sequence length
        "num_train_samples": 1000,
        "train_data_path": "data/train_datadx.pt"
    }

# If the file does not exist, generate and save the test data
def check_and_generate_data(train_params):
    # Create a data folder if it doesn't exist
    os.makedirs(os.path.dirname(train_params["train_data_path"]), exist_ok=True)
    # generate_and_save_data(train_params["num_train_samples"], train_params["seq_length"],
    #                        train_params["train_data_path"])
    if not os.path.exists(train_params["train_data_path"]):
        generate_and_save_data(train_params["num_train_samples"], train_params["seq_length"], train_params["train_data_path"])
