import torch
import numpy as np
from phy_env import QubitEnv
from dqn_agent import Agent
from dqn_main import get_obs
from numpy.random import default_rng
import os
import glob


rng = default_rng(seed=22)

max_qfi1 = 1600
max_qfi = max_qfi1/4
def use_pred_sme(env, full_state, rng):
    pred_model = False
    if pred_model:
        mid_bit, pred_mid_bit = env.pred_sme_evo(full_state, rng=rng)
        mid_bit_obs = get_obs(pred_mid_bit)
    else:
        mid_bit = env.sme_evo(full_state, rng=rng)
        mid_bit_obs = get_obs(mid_bit)
    return mid_bit, mid_bit_obs

N = 4
n_actions = 15
total_T = 10
Hamiltonian_params = dict(
    w0=0.75,
    w_c=0,
    g=0.1,
    N=N,
    meas_strength=1.5
)

Env_params = dict(
    discrete_evolution=False,
    use_density_matrix=True,
    n_actions=n_actions,  # action set size
    step_rate=1,  # [2, 3, 4]
    total_T=total_T,  # total_evolve = total_T * np.pi
    dx=0.001,
    seed=2024,
    Hamiltonian_params=Hamiltonian_params,
    reward_form='CFI',
    max_qfi=max_qfi1,
    N=N,
    psi_cavity=0,
    dqn_agent=True
)

episodes = 100
def test_model(model_path, episodes=episodes):

    env = QubitEnv(**Env_params)


    agent = Agent(env.observation_space, env.n_actions, env)
    agent.load_model(model_path)

    total_rewards = []
    final_rewards = []
    reward_step = [0] * total_T

    for e in range(episodes):
        print(e)
        full_state, bit_state = env.reset()
        mid_bit, mid_bit_obs = use_pred_sme(env, full_state, rng=rng)

        episode_reward = 0
        for step in range(Env_params["total_T"]):
            bit_obs = mid_bit_obs
            action = agent.act(bit_obs, eps=0.0)
            next_full_state, next_bit_state, obs, reward, or_reward, done = env.step(action, full_state, mid_bit,
                                                                                     steps=step)

            next_mid_bit, next_mid_bit_obs = use_pred_sme(env, next_full_state, rng=rng)




            full_state, bit_state = next_full_state, next_bit_state
            mid_bit = next_mid_bit
            mid_bit_obs = next_mid_bit_obs
            or_reward = np.exp(or_reward)*max_qfi
            episode_reward += or_reward
            reward_step[step] += or_reward


            if done:
                final_reward = or_reward
                final_rewards.append(final_reward)
                break
    avg_CFI = 4 * np.mean(final_rewards)
    avg_CFI_step = [4*x / episodes for x in reward_step]
    print(f"Average Reward over {episodes} episodes: {avg_CFI}")
    print(f"Average Reward_step over {episodes} episodes: {avg_CFI_step}")
    return avg_CFI, avg_CFI_step

if __name__ == "__main__":

    model_dir = "./save_model/Pred_model/"

    model_paths = sorted(glob.glob(os.path.join(model_dir, "w00.75T10g0.1action15episode_5*.pth")))

    print(f"Found {len(model_paths)} models.")

    results = []

    for model_path in model_paths:
        print(f"test model:{model_path}")
        avg_CFI, avg_CFI_step = test_model(model_path)

        results.append({
            "model": os.path.basename(model_path),
            "avg_CFI": avg_CFI,
            "stepwise_CFI": avg_CFI_step,
        })
